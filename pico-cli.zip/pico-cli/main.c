#include <stdio.h>
#include <string.h>
#include "pico/stdlib.h"

#define MAX_CMD_LEN 64

void cmd_help();
void cmd_led_on();
void cmd_led_off();
void cmd_status();

int main() {
    stdio_init_all();
    gpio_init(PICO_DEFAULT_LED_PIN);
    gpio_set_dir(PICO_DEFAULT_LED_PIN, GPIO_OUT);

    char buffer[MAX_CMD_LEN];
    int index = 0;

    printf("Pico CLI Ready.\nType 'help' for commands.\n> ");

    while (true) {
        int ch = getchar_timeout_us(0);

        if (ch == PICO_ERROR_TIMEOUT) {
            continue;
        }

        if (ch == '\r' || ch == '\n') {
            buffer[index] = '\0';
            printf("\n");

            if (index > 0) {
                if (strcmp(buffer, "help") == 0) cmd_help();
                else if (strcmp(buffer, "led on") == 0) cmd_led_on();
                else if (strcmp(buffer, "led off") == 0) cmd_led_off();
                else if (strcmp(buffer, "status") == 0) cmd_status();
                else printf("Unknown command: %s\n", buffer);
            }

            index = 0;
            printf("> ");
        }
        else if (index < MAX_CMD_LEN - 1) {
            buffer[index++] = ch;
            putchar(ch);
        }
    }
}

void cmd_help() {
    printf("Available commands:\n");
    printf("  help     - Show this help message\n");
    printf("  led on   - Turn LED on\n");
    printf("  led off  - Turn LED off\n");
    printf("  status   - Show system status\n");
}

void cmd_led_on() {
    gpio_put(PICO_DEFAULT_LED_PIN, 1);
    printf("LED is now ON\n");
}

void cmd_led_off() {
    gpio_put(PICO_DEFAULT_LED_PIN, 0);
    printf("LED is now OFF\n");
}

void cmd_status() {
    printf("System OK. LED state: %s\n",
        gpio_get(PICO_DEFAULT_LED_PIN) ? "ON" : "OFF");
}
